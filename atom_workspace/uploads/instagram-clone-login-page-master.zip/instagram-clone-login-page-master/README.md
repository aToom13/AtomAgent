# :copyright: Instagram clone Login Page

- A responsive login page from Instagram with HTML and CSS (flexbox)
- Flexbox cross-browser

## Desktop

![Login page desktop version](https://raw.githubusercontent.com/laisfrigerio/instagram-clone-login-page/master/screenshots/desktop.png)

## Tablet

![Login page tablet version](https://raw.githubusercontent.com/laisfrigerio/instagram-clone-login-page/master/screenshots/tablet.png)

## Mobile

![Login page mobile version](https://raw.githubusercontent.com/laisfrigerio/instagram-clone-login-page/master/screenshots/mobile.png)

## :muscle: Inspiração

Bootcamp Javascript Game Developer from Digital Innovation One